import React from 'react';

import './card.css';

export default function Card(){
	//returning jsx
const text = 'Blastoid' 
const texth2= 'Pickachu'

	return (
		<div className='card'>
		<h2>{text}</h2>
		{text}

		</div>

	)

}